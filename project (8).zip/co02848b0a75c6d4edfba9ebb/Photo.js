import React from "react"
export default function Photo(){
    return (
        
        <div id="photo"> 
        <img src="./208r1a0505.jpg" alt="my photo" />
        </div>
    
    
    )
}