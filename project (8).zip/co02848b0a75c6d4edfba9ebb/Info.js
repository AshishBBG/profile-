import React from "react"
export default function Info(){
    return (
        <div className="information">
        <div className="about-info"><h3><span>About</span></h3>
        <p>I am a student and a aim to become a web developer I am very curious about learning new languages such as HTML, CSS, JavaScript, React framework, PHP, MYSQL, Java, C, Python and these languages I know..</p>
        <h3><span>Interest</span></h3>
        <p>My intrest is to share my knowledge to everyone so that no one would roming arond and say I don't have resources, I feel very happy if anyone ask some doubt I love to solve problem 😍</p>
        </div>
        </div>
    )
}