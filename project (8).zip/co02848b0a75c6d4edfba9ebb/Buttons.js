import React from "react"
export default function Buttons() {
    return (
        <div className="button-center">
        <a  href="<mailto:208r1a0505@gmail.com "><button className="btn" id="email">Email</button></a>
        <a href="https//notesofeng.blogspot.com"><button className="btn" id="linked-in">LinkedIn</button></a>
        </div>
        
        
    )
}