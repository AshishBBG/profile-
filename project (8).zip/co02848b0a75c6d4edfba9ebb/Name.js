import React from "react"

export default function Name(){
    return (
        <div className="name">
        <h2>Ashish Singh</h2>
        <h5 className="frontend-developer">Frontend Developer</h5>
        <h6><a href="http://abhisingh156.blogspot.com">abhisingh156</a></h6>    
        </div>
    )
}