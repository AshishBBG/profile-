import React from "react"
export default function Footer(){
    return (
        <div className="footer">
            <a href="https://www.facebook.com/profile.php?id=100055048182192" className="fa fa-facebook"></a>
            <a href="https://notesofeng.blogspot.com/" className="fa fa-twitter"></a>
            <a href="https://wa.me/91+7382940558" className="fa fa-whatsapp"></a>
            <a href="https://youtu.be/RkUA_YmBfVc" className="fa fa-youtube"></a>
             <p></p>
        </div>
       
    )
}